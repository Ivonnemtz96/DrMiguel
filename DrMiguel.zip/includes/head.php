<head>
    <?
        include('includes/tagHead.php');
    ?>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <meta name="description" content=" Médico egresado con distinción de la Universidad Nacional Autónoma de México (UNAM). Mi
                        trayectoria profesional se ha enfocado en ofrecer atención médica de calidad">
    <link href="assets/images/favicon/favicon2.png" rel="icon">
    <title>Dr. Miguel Blanco</title>

    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;700&amp;family=Roboto:wght@400;700&amp;display=swap">
    <link rel="stylesheet" href="use.fontawesome.com/releases/v5.15.1/css/all.css">
    <link rel="stylesheet" href="assets/css/libraries.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- captcha -->
 <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>